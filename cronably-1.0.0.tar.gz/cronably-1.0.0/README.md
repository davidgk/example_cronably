# CRONABLY

## Introduction

Cronably allows you run python scripts with configured repetitions easily.
If want to use it from here you can [Clone and install locally](#Clone and install locally)

Let me show you some features


## About How it Running
Cronably can run just configuring the anotation like this:
```
from cronably import Cronably

@Cronably(name="HOLA_MUNDO")
def my_process():
    print "Hola Mundo"

```

Or using an external file, it should be named "cronably.txt" , it should be in the same path as the process:

```
from cronably.implementation import Cronably


@Cronably(ext_config=True)
def my_process_from_file():
    print "Hola Mundo"


if __name__ == '__main__':
    my_process_from_file()
```

And file should contains this:

```
name=HOLA_MUNDO
```
If you want to run from file, is mandatory to add allways the param ext_config. If you add that all
parameters will be taken from file.If you add here and also into the file, it will be overwritten by file
, in the other hand, if it doesn't exists in the file , will be used the configurations ones.

For this simple step you are telling to cronably that the method should run once. It's beacuse 
the default parameter loop, by default is 1. The field "name" is mandatory.


## About Loops
You can tell to cronably the times you want to repeat, ( like a loop), with nothing, it will run only once
If you put : 

```
@Cronably(name="HOLA_MUNDO", loops = 10)
def my_process():
    print "Hola Mundo"

```
It will run 10 times

If you put : 

```
@Cronably(name="HOLA_MUNDO", loops = -1)
def my_process():
    print "Hola Mundo"

```
It will not stop running, until you kill the process

### Loops and repetitions

Loops live together with repetitions, it means you can repeat the process every lapse of time, but if you configure an amount of times to do it,
it will stop once you accomplish this amount of times. 

## About Repetitions

### Concrete elapse of times

#### Within the code:
```
@Cronably(name="HOLA_MUNDO", loops=10, repetition_frame= VALUE, repetition_period=15)
def my_process():
    print "Hola Mundo"
```
repetition_frame can be: 
* HOURS
* MINUTES
* SECONDS
* DAYS

it will run 10 times the process every 15 MINUTES, from the moment you start the script


#### Within the file:
```
name=HOLA_MUNDO
loops=10
repetition.frame=HOURS
repetition.period=2

```

it will run 10 times the process every 2 HOURS

The repetitions will start from the moment you run the script.

### Specific Days 

You should put as frame the value: WEEKLY

### Within the code:
```
@Cronably(name="HOLA_MUNDO", loops=10, repetition_frame= WEEKLY, repetition_period_day='Monday',repetition_period_time='10:00' )
def my_process():
    print "Hola Mundo"
```

it will run 10 times the process every Monday at 10:00 (AM)
Attention: I'm using 0:00 to 23:59 style time.

#### Within the file:
```
name=HOLA_MUNDO
loops=10
repetition.frame=WEEKLY
repetition.period.day=Monday
repetition.period.time=10:00
```

it will run 10 times the process every Monday at 10:00 (AM)

The repetitions will start from the moment you run the script.


### Specific Dates
**TODO**

## About Reporting
**TODO**


## Clone and install locally

Steps once you clone it:

1.- build : run _python setup.py sdist bdist_wheel_.

It will create the lib cronably.X.X.X.tar.gz in dist folder.

2.- In your proyect , if you have pipenv run:

_pipenv install <your path where is cronably>cronably-1.0.0.tar.gz_

3.- You can check this example running

