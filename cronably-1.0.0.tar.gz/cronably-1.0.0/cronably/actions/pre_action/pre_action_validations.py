from cronably.utils.cronably_exception import CronablyException


class PreActionValidations(object):

    def __init__(self, params):
        self.parameters = params
        self.conf_dict_file = {'frame':'repetition.frame','period':'repetition.period', 'day':"repetition.period.day", 'time':"repetition.period.time" }
        self.conf_dict_code = {'frame':'repetition_frame','period':'repetition_period', 'day':"repetition_period_day", 'time':"repetition_period_time" }

    def run(self):
        print '...Validations'
        if self.is_loading_from_file():
            self.check_commands_from_file()
        self.job_has_name()

    def check_param(self, param, default):
        if param in self.parameters.keys():
            return self.parameters[param]
        return default

    def is_loading_from_file(self):
        return self.check_param("ext_config", False)

    def check_commands_from_file(self):
        with open('./cronably.txt', 'r') as crx:
            for value in crx:
                command = value.strip().split('=')
                key = command[0]
                value = command[1].upper() if key=='name' else command[1].lower()
                self.parameters[command[0].lower()] = value

    def job_has_name(self):
        if not self.check_param('name', False):
            raise CronablyException("You should add a name into your Cronably annotation")

    def has_repetition_strategy(self):
        return self.evaluate_period_conditions(self._get_config('frame'))

    def evaluate_period_conditions(self, frame):
        period = self._get_config('period')
        day = self._get_config('day')
        time = self._get_config('time')
        ok_period = self.evaluate_day_time(period, day, time)
        return self.evaluate_repetitions(self.check_param(frame, False), ok_period, 'frame', 'period')

    def evaluate_day_time(self,period, day, time):
        if self.check_param(period, False):
            return True
        else:
            return self.evaluate_repetitions(
                self.check_param(day, False)
                , self.check_param(time, False), day, time)

    def evaluate_repetitions(self, condition_a, condition_b, parm_a, parm_b):
        only_frame = condition_a and not condition_b
        only_period = not condition_a and condition_b
        if not condition_a and not condition_b:
            return False
        elif only_frame or only_period:
            raise CronablyException('Repetition miss params, check you add %s and %s' % (parm_a, parm_b))
        else:
            return True

    def _get_config(self, param):
        if self.check_param("ext_config", False):
            return self.conf_dict_file[param]
        else:
            return self.conf_dict_code[param]
